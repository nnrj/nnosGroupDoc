#include <stdarg.h>
#include <stdio.h>
void getAscCode(char *c,char buff[])
{
  unsigned long offset;
  FILE *ASC;
  if((ASC=fopen("asc16","rb"))==NULL)
	{printf("cant:");
	 getch() ;
	 exit(0);
	 }
   offset=*(c)*16+1;
   fseek(ASC,offset,SEEK_SET);
   fread(buff,16,1,ASC);
   printf("ASCII:%d,offset:%d\n\r",*c,offset);
}
void getHzkCode(char *c,char buff[])
{
 unsigned char qh,wh;
 unsigned long offset;
 FILE *HZK;
 if((HZK=fopen("hzk16","rb"))==NULL)
 {printf("error");
  getch();
  exit(0);
  }
  qh=*(c)-0xa0;
  wh=*(c+1)-0xa0;
  offset=(94*(qh-1)+(wh-1))*32L;
  fseek(HZK,offset,SEEK_SET);
  fread(buff,32,1,HZK);
  printf("qh:%d,wh:%d,offset:%ld\n\r",qh,wh,offset);
  }
void printAscChar(char *mat,char *c1,char *c2)
{
 int i,j;
 for(i=0;i<16;i++)
  {for(j=0;j<8;j++)
   if(mat[i]&(0x80>>j))
   printf("%s",c1);
   else printf("%s",c2);
   printf("\n");
  }
}
void printHzkChar(char *mat,char *c1,char *c2)
{
 int i,j,k;
 for(i=0;i<16;i++)
  {for(j=0;j<2;j++)
    for(k=0;k<8;k++)
     if(mat[i*2+j]&(0x80>>k))
     printf("%s",c1);
     else printf("%s",c2);
	 printf("\n");
}
}
void main()
{
 unsigned char *AscC="A";
 unsigned char *AscC1=".";
 unsigned char *AscC2=" ";
 unsigned char *HzkC="��";
 unsigned char *HzkC1=".";
 unsigned char *HzkC2=" ";
 char *asc;
 char *hzk;
 char buffer1[16];
 char buffer2[32];
 getAscCode(AscC,buffer1);
 asc=buffer1;
 printAscChar(asc,AscC1,AscC2);
 getch();
 clrscr();
 getHzkCode(HzkC,buffer2);
 hzk=buffer2;
 printHzkChar(hzk,HzkC1,HzkC2);
 getch();
}

