#include "print.h"
int main()
{
	put_str("put_str finish\n");
	while(1);
	return 0;
}
