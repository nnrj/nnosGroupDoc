#ifndef __LIB_KERNEL_PRINT_H
#define __LIB_KERNEL_PRINT_H

void put_char(int char_asci);
void put_str(char* message);
#endif
