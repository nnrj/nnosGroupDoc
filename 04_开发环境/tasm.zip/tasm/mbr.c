#include "stdio.h"
#include "stdarg.h"
#include "conio.h"
void printchar(char c,char line_x,char col_y,char corlor);
void printstr(char *s,char start_line_x,char start_col_y,char corlor);
int main (void)
{       printstr("hello world\n",5,10,0x0c);
        return 0;
}
void printchar(char c,char line_x,char col_y,char corlor)
{
        *(char *)(0xb8000+line_x*160+2*col_y) =c;
        *(char *)(0xb8000+line_x*160+2*col_y+1) =corlor;
}

/*��ӡһ���ַ���,����:�ַ����׵�ַ,��ʼ�к�,��ʼ�к�,�ַ���ɫ*/
void printstr(char *s,char start_line_x,char start_col_y,char corlor)
{
        do
        {
        printchar(*s,start_line_x,start_col_y,corlor);
        start_col_y++;
        }
        while (*(s++)!='\0');
}
