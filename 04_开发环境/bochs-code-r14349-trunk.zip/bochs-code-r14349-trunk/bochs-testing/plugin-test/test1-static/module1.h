extern const char *module_name;
extern int operate (int a, int b);
