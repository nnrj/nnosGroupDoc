extern int register_module (const char *name);
