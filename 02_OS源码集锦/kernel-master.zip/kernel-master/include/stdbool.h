#ifndef STDBOOL_H_INCLUDED
#define STDBOOL_H_INCLUDED

#define bool  _Bool
#define true  1
#define false 0

#endif
