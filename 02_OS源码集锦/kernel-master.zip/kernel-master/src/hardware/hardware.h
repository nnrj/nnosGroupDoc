#ifndef HARDWARE_H_INCLUDED
#define HARDWARE_H_INCLUDED

#include "ia32.h"

#endif
