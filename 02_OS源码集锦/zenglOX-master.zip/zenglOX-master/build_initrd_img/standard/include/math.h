#ifndef _MATH_H_
#define _MATH_H_

double modf(double val, double *iptr);

#endif

