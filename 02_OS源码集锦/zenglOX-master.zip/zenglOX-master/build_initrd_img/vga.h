// vga.h -- 和vga相关的结构定义

#ifndef _VGA_H_
#define _VGA_H_

#include "common.h"

#define VGA_MODE_80X25_TEXT 0
#define VGA_MODE_320X200X256 1
#define VGA_MODE_640X480X16 2

#endif // _VGA_H_

