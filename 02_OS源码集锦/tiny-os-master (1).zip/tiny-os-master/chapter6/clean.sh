#!/bin/sh

rm -f disk.img *.bin kernel/*.bin kernel/*.o lib/kernel/*.o
