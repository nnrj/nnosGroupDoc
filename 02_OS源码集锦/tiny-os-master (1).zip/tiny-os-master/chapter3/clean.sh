#!/bin/sh

rm -f disk.img *.bin
