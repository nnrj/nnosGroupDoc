#!/bin/sh

rm -rf disk.img build/ 
