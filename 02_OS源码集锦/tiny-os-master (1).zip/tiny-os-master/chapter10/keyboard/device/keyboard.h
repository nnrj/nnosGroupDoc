# ifndef _DEVICE_KEYBOARD_H
# define _DEVICE_KEYBOARD_H

void keyboard_init(void);

# endif