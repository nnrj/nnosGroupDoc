fd kernel
=========

FreeDOS kernel - branch from 2042 SVN 0xFD kernel

http://www.fdos.org/kernel/

The FreeDOS kernel implements the core MS/PC-DOS (R) compatible functions.  It is derived from Pat Villani's DOS-C kernel and released under the GPL v2.  Please see http://www.freedos.org/ for more details about the FreeDOS (TM) Project.   Compiled kernels ready to use (just copy kernel.sys over an existing install) are available at http://www.fdos.org/kernel/testing/git/ - also available are the source archive and fdpkg compatible packages.


This version of the kernel is intended only for 8086+ or 80386+ IBM compatible computers in continuation of the goals of the FreeDOS Project.  Please see http://www.fdos.org/kernel for my 0xDC kernel that is work on merging back in some of the original portability aspects and other supported features at the cost of some compatibility with older hardware/software.

Please feel free to email me - PerditionC@gmail.com
2020

[![Build](../../workflows/Build/badge.svg)](../../actions)

[![Build Status](https://travis-ci.com/FDOS/kernel.svg?branch=master)](https://travis-ci.com/FDOS/kernel)
Now with automatic builds and soon tests on [Travis CI](http://travis-ci.com)
