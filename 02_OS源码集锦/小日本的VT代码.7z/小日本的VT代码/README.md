BitVisor is a tiny hypervisor initially designed for mediating I/O
access from a single guest OS. Its implementation is mature enough to
run Windows and Linux, and can be used as a generic platform for
various research and development projects.
