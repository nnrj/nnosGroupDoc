unsigned int ip_sys_now (void);
