#define PERF_START
#define PERF_STOP(x)
