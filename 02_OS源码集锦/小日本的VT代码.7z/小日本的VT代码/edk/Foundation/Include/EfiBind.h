#ifdef __x86_64__
#include "x64/EfiBind.h"
#else
#include "Ia32/EfiBind.h"
#endif
