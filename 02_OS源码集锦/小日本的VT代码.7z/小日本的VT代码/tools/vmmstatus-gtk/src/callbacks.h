#include <gtk/gtk.h>


void
on_dialog1_destroy                     (GtkObject       *object,
                                        gpointer         user_data);

void
on_closebutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data);
