#!/bin/bash
cp -rf ./ini/Makefile_linux ./Makefile
make run
