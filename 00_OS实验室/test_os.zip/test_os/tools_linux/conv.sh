#!/bin/sh

patch -b ./Makefile ../z_tools/Makefile.patch

