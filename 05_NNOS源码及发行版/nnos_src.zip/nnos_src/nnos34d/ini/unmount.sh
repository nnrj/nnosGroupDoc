#!/bin/bash
umount /dev/sdb1