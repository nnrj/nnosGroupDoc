#!/bin/bash
mount /dev/sdb1 /usb/
sudo dd if=boot.img of=/dev/sdb1