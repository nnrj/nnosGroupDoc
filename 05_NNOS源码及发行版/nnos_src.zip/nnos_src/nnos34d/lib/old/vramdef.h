#define COL8_000000 0   //纯黑
#define COL8_FF0000 1   //纯红
#define COL8_00FF00 2   //纯绿
#define COL8_0000FF 3   //纯蓝
#define COL8_FFFF00 4   //纯黄
#define COL8_FF00FF 5   //纯紫
#define COL8_00FFFF 6   //纯青
#define COL8_FFFFFF 7   //纯白
#define COL8_C6C6C6 8   //纯灰
#define COL8_840000 9   //暗红
#define COL8_008400 10  //暗绿
#define COL8_000084 11  //靛青
#define COL8_848400 12  //暗黄
#define COL8_840084 13  //暗紫
#define COL8_008484 14  //靛蓝
#define COL8_848484 15  //暗灰

//#define VRAM_MODE01 
