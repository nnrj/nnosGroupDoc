#!/bin/bash
cp -rf ./ini/Makefile_linux Makefile
make getnask
make run
