void api_printc(int c);

void NNOSMain(){
	int i = 0;
	while(1){
		i++;
		api_printc(i);
	}
}