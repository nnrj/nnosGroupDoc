#include "api.h"

int exit(int status){
	api_return();
}
