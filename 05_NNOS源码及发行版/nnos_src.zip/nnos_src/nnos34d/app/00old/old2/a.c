void api_printc(int c);

void NNOSMain(){
	api_printc('N');
	return;
}