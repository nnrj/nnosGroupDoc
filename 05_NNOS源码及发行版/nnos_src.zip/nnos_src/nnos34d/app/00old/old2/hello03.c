void api_printc(int c);

void NNOSMain(){
	api_printc('H');
	api_printc('e');
	api_printc('l');
	api_printc('l');
	api_printc('0');
	api_printc(' ');
	api_printc('w');
	api_printc('o');
	api_printc('r');
	api_printc('l');
	api_printc('d');
	api_printc(',');
	api_printc('n');	
	api_printc('n');
	api_printc('o');
	api_printc('s');
	api_printc('!');
}
