void NNOSMain(){
	*((char *) 0x00102600) = 0;
	return;
}
