void api_putchar(int c);

void NNOSMain(){
	api_putchar('h');
	api_putchar('e');
	api_putchar('l');
	api_putchar('l');
	api_putchar('0');
	return;
}

/* void NNOSMain(){
	api_putchar('H');
	api_putchar('e');
	api_putchar('l');
	api_putchar('l');
	api_putchar('0');
	api_putchar(' ');
	api_putchar('w');
	api_putchar('o');
	api_putchar('r');
	api_putchar('l');
	api_putchar('d');
	api_putchar(',');
	api_putchar('n');	
	api_putchar('n');
	api_putchar('o');
	api_putchar('s');
	api_putchar('!');
} */
