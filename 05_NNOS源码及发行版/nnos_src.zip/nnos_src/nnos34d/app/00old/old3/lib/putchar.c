#include "../api.h"

int putchar(int c){
	api_printc(c);
	return c;
}