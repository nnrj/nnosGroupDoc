#include "api.h"
//#include <stdio.h>

void NNOSMain(){
	//char str[] = "hello";
	//printf("%s",str);
	printf("Hello,%s_0.%d test std.\n","NNOS",32);
	//char c = putchar('a');
	//printf("\n%s",c);
	exit(1);
}
