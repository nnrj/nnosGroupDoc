void api_printl(char *s);
void api_return();

void NNOSMain(){
	api_printl("Hello world, nnos API.");
	api_return();
}