void api_printc(int c);
void api_return();

void NNOSMain(){
	api_printc('N');
	//return;
	api_return();
}